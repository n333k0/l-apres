"""L'Après logo builder: real font files -> shaped (HarfBuzz, kerning on) -> outlined
-> boolean-merged (skia-pathops) -> tight SVGs cropped to their own ink.

Run:  <venv>/bin/python tools/build.py
Out:  logos/r2/*.svg (black vectors, one compound path each, accent separate)
      r2-data.js (same marks for the page, fill = currentColor)
"""
import json, math, os, re
from pathlib import Path as P

import pathops
import uharfbuzz as hb
from fontTools.misc.transform import Transform
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.ttLib import TTFont
from fontTools.ttLib.removeOverlaps import removeOverlaps
from fontTools.varLib import instancer

ROOT = P(__file__).resolve().parent.parent
FONTS = ROOT / "fonts"
STATIC = FONTS / "static"
OUT = ROOT / "logos" / "r2"
STATIC.mkdir(parents=True, exist_ok=True)
OUT.mkdir(parents=True, exist_ok=True)

APOS = "’"  # the real typographic apostrophe, always

# ---------------------------------------------------------------- fonts
SPECS = {
    "bodoni":   ("BodoniModa[opsz,wght].ttf", {"opsz": 28, "wght": 500}),
    "bodonik":  ("BodoniModa[opsz,wght].ttf", {"opsz": 11, "wght": 600}),
    "bodoni7":  ("BodoniModa[opsz,wght].ttf", {"opsz": 28, "wght": 700}),
    "italiana": ("Italiana-Regular.ttf", None),
    "cinzel":   ("Cinzel[wght].ttf", {"wght": 500}),
    "abril":    ("AbrilFatface-Regular.ttf", None),
    "caslon":   ("LibreCaslonDisplay-Regular.ttf", None),
    "gloock":   ("Gloock-Regular.ttf", None),
    "prata":    ("Prata-Regular.ttf", None),
    "mono":     ("DMMono-Medium.ttf", None),
    "bodoni8":  ("BodoniModa[opsz,wght].ttf", {"opsz": 28, "wght": 800}),
    "bodonit":  ("BodoniModa-Italic[opsz,wght].ttf", {"opsz": 28, "wght": 400}),
    "cinzel6":  ("Cinzel[wght].ttf", {"wght": 600}),
    "mono4":    ("DMMono-Regular.ttf", None),
    "sacramento": ("Sacramento-Regular.ttf", None),
    "yellowtail": ("Yellowtail-Regular.ttf", None),
    "mrdafoe":  ("MrDafoe-Regular.ttf", None),
    "pinyon":   ("PinyonScript-Regular.ttf", None),
    "greatvibes": ("GreatVibes-Regular.ttf", None),
    "monsieur": ("MonsieurLaDoulaise-Regular.ttf", None),
    "allura":   ("Allura-Regular.ttf", None),
    "damion":   ("Damion-Regular.ttf", None),
    "cond6":    ("NotoSerifDisplay[wdth,wght].ttf", {"wdth": 62.5, "wght": 600}),
    "cond3":    ("NotoSerifDisplay[wdth,wght].ttf", {"wdth": 62.5, "wght": 300}),
    "cond8":    ("NotoSerifDisplay[wdth,wght].ttf", {"wdth": 62.5, "wght": 800}),
}


class Face:
    def __init__(self, key):
        src, loc = SPECS[key]
        out = STATIC / f"{key}.ttf"
        if not out.exists():
            f = TTFont(FONTS / src)
            if loc:
                f = instancer.instantiateVariableFont(f, loc)
            try:
                removeOverlaps(f)
            except Exception as e:  # static fonts without overlaps
                print("removeOverlaps skipped", key, e)
            f.save(out)
        self.tt = TTFont(out)
        self.gs = self.tt.getGlyphSet()
        self.order = self.tt.getGlyphOrder()
        self.upem = self.tt["head"].unitsPerEm
        os2 = self.tt["OS/2"]
        self.cap = getattr(os2, "sCapHeight", 0) or self.upem * 0.7
        self.xh = getattr(os2, "sxHeight", 0) or self.upem * 0.5
        blob = hb.Blob.from_file_path(str(out))
        self.hbfont = hb.Font(hb.Face(blob))


_faces = {}


def face(k):
    if k not in _faces:
        _faces[k] = Face(k)
    return _faces[k]


# ---------------------------------------------------------------- path helpers
def new():
    return pathops.Path()


def union(*paths):
    out = new()
    for p in paths:
        if p is None:
            continue
        out = pathops.op(out, p, pathops.PathOp.UNION)
    return out


def minus(a, b):
    return pathops.op(a, b, pathops.PathOp.DIFFERENCE)


def moved(p, dx=0, dy=0, sx=1, sy=1):
    q = new()
    p.draw(TransformPen(q.getPen(), (sx, 0, 0, sy, dx, dy)))
    return q


def bounds(p):
    return p.bounds  # xmin, ymin, xmax, ymax (svg coords, y down)


def poly(pts):
    p = new()
    pen = p.getPen()
    pen.moveTo(pts[0])
    for q in pts[1:]:
        pen.lineTo(q)
    pen.closePath()
    return p


def rect(x, y, w, h):
    return poly([(x, y), (x + w, y), (x + w, y + h), (x, y + h)])


def circle(cx, cy, r):
    k = 0.5522847498 * r
    p = new()
    pen = p.getPen()
    pen.moveTo((cx + r, cy))
    pen.curveTo((cx + r, cy + k), (cx + k, cy + r), (cx, cy + r))
    pen.curveTo((cx - k, cy + r), (cx - r, cy + k), (cx - r, cy))
    pen.curveTo((cx - r, cy - k), (cx - k, cy - r), (cx, cy - r))
    pen.curveTo((cx + k, cy - r), (cx + r, cy - k), (cx + r, cy))
    pen.closePath()
    return p


def ring(cx, cy, r, w):
    return minus(circle(cx, cy, r + w / 2), circle(cx, cy, r - w / 2))


def spark(cx, cy, h):
    """Four-point spark, height h, centred."""
    s = h / 100
    pts = lambda x, y: (cx + (x - 50) * s, cy + (y - 50) * s)
    p = new()
    pen = p.getPen()
    pen.moveTo(pts(50, 0))
    pen.curveTo(pts(53, 35), pts(65, 47), pts(100, 50))
    pen.curveTo(pts(65, 53), pts(53, 65), pts(50, 100))
    pen.curveTo(pts(47, 65), pts(35, 53), pts(0, 50))
    pen.curveTo(pts(35, 47), pts(47, 35), pts(50, 0))
    pen.closePath()
    return p


def inset_triangle(pts, d):
    (ax, ay), (bx, by), (cx, cy) = pts
    a = math.dist((bx, by), (cx, cy))
    b = math.dist((ax, ay), (cx, cy))
    c = math.dist((ax, ay), (bx, by))
    per = a + b + c
    ix, iy = (a * ax + b * bx + c * cx) / per, (a * ay + b * by + c * cy) / per
    s = per / 2
    area = math.sqrt(max(s * (s - a) * (s - b) * (s - c), 0))
    rin = area / s
    k = 1 - d / rin
    return [(ix + (x - ix) * k, iy + (y - iy) * k) for x, y in pts]


# ---------------------------------------------------------------- type
def shape(fk, text):
    f = face(fk)
    buf = hb.Buffer()
    buf.add_str(text)
    buf.guess_segment_properties()
    hb.shape(f.hbfont, buf, {"kern": True, "liga": False})
    return f, [(f.order[i.codepoint], p.x_advance, p.x_offset, p.y_offset) for i, p in zip(buf.glyph_infos, buf.glyph_positions)]


def line(fk, text, size, x=0, base=0, track=0.0, anchor="middle"):
    """Set one line. size = font size in units; track in em.
    Returns dict(path, glyphs=[(char, path)], width, cap, xh)."""
    LOG.append((fk, text, round(track, 3)))
    f, gl = shape(fk, text)
    s = size / f.upem
    adv = [g[1] * s for g in gl]
    tr = track * size
    width = sum(adv) + tr * (len(gl) - 1)
    x0 = x - width / 2 if anchor == "middle" else (x - width if anchor == "end" else x)
    out, glyphs, cur = new(), [], x0
    for ch, (name, a, ox, oy) in zip(text, gl):
        gp = new()
        f.gs[name].draw(TransformPen(gp.getPen(glyphSet=f.gs), Transform().translate(cur + ox * s, base - oy * s).scale(s, -s)))
        glyphs.append((ch, gp))
        out = union(out, gp)
        cur += a * s + tr
    return dict(path=out, glyphs=glyphs, width=width, cap=f.cap * s, xh=f.xh * s, size=size)


def ink_center(p, cx=None, cy=None):
    x0, y0, x1, y1 = bounds(p)
    return moved(p, 0 if cx is None else cx - (x0 + x1) / 2, 0 if cy is None else cy - (y0 + y1) / 2)


def arc_text(fk, text, size, cx, cy, r, track=0.0, where="top"):
    """Text on a circle. top: reads clockwise over the top, baseline radius r (letters point out).
    bottom: reads left to right under the centre, baseline radius r (letters point in)."""
    LOG.append((fk, text, round(track, 3)))
    f, gl = shape(fk, text)
    s = size / f.upem
    adv = [g[1] * s for g in gl]
    tr = track * size
    L = sum(adv) + tr * (len(gl) - 1)
    out, u = new(), 0.0
    for (name, a, ox, oy), aw in zip(gl, adv):
        mid = u + aw / 2 - L / 2
        if where == "top":
            th = -math.pi / 2 + mid / r
            rot = th + math.pi / 2
        else:
            th = math.pi / 2 - mid / r
            rot = th - math.pi / 2
        px, py = cx + r * math.cos(th), cy + r * math.sin(th)
        T = Transform().translate(px, py).rotate(rot).translate(-aw / 2, 0).scale(s, -s)
        gp = new()
        f.gs[name].draw(TransformPen(gp.getPen(glyphSet=f.gs), T))
        out = union(out, gp)
        u += aw + tr
    return out


# ---------------------------------------------------------------- building blocks
def spark_word(fk, size, x=0, base=0, track=0.04, lower=False, ratio=0.44, gap=0.17):
    """L’APRES with a spark in place of the grave accent (over E / e)."""
    txt = f"l{APOS}apres" if lower else f"L{APOS}APRES"
    t = line(fk, txt, size, x, base, track)
    target = "e" if lower else "E"
    ep = [g for ch, g in t["glyphs"] if ch == target][0]
    ex0, ey0, ex1, ey1 = bounds(ep)
    ref = t["xh"] if lower else t["cap"]
    h = ratio * ref * (1.15 if lower else 1)
    acc = spark((ex0 + ex1) / 2, ey0 - gap * ref - h / 2, h)
    return dict(word=t["path"], acc=acc, width=t["width"], cap=t["cap"], top=ey0 - gap * ref - h, base=base)


def lodge_line(width_ref, y, size=None, cx=0, rules=True, text="HI-FI LISTENING LODGE", track=0.32, fk="mono"):
    size = size or width_ref * 0.052
    t = line(fk, text, size, cx, y, track)
    p = ink_center(t["path"], cx=cx)
    if rules:
        x0, y0, x1, y1 = bounds(p)
        mid = (y0 + y1) / 2
        gap = size * 0.9
        rl = max(width_ref * 0.5 - (x1 - x0) / 2 - gap, size * 1.5)
        th = max(size * 0.07, 0.8)
        p = union(p, rect(x0 - gap - rl, mid - th / 2, rl, th), rect(x1 + gap, mid - th / 2, rl, th))
    return p


# ---------------------------------------------------------------- type specs (for the kit)
LOG = []
FONT_INFO = {
    "bodoni":  ("Bodoni Moda", "opsz 28 · wght 500", "BodoniModa-Variable.ttf", "Bodoni+Moda", "bodonimoda"),
    "bodonik": ("Bodoni Moda", "opsz 11 · wght 600", "BodoniModa-Variable.ttf", "Bodoni+Moda", "bodonimoda"),
    "bodoni7": ("Bodoni Moda", "opsz 28 · wght 700", "BodoniModa-Variable.ttf", "Bodoni+Moda", "bodonimoda"),
    "italiana": ("Italiana", "Regular", "Italiana-Regular.ttf", "Italiana", "italiana"),
    "cinzel":  ("Cinzel", "wght 500", "Cinzel-Variable.ttf", "Cinzel", "cinzel"),
    "abril":   ("Abril Fatface", "Regular", "AbrilFatface-Regular.ttf", "Abril+Fatface", "abrilfatface"),
    "caslon":  ("Libre Caslon Display", "Regular", "LibreCaslonDisplay-Regular.ttf", "Libre+Caslon+Display", "librecaslondisplay"),
    "gloock":  ("Gloock", "Regular", "Gloock-Regular.ttf", "Gloock", "gloock"),
    "prata":   ("Prata", "Regular", "Prata-Regular.ttf", "Prata", "prata"),
    "mono":    ("DM Mono", "Medium", "DMMono-Medium.ttf", "DM+Mono", "dmmono"),
    "bodoni8": ("Bodoni Moda", "opsz 28 · wght 800", "BodoniModa-Variable.ttf", "Bodoni+Moda", "bodonimoda"),
    "bodonit": ("Bodoni Moda Italic", "opsz 28 · wght 400", "BodoniModa-Italic-Variable.ttf", "Bodoni+Moda", "bodonimoda"),
    "cinzel6": ("Cinzel", "wght 600", "Cinzel-Variable.ttf", "Cinzel", "cinzel"),
    "mono4":   ("DM Mono", "Regular", "DMMono-Regular.ttf", "DM+Mono", "dmmono"),
    "sacramento": ("Sacramento", "Regular", "Sacramento-Regular.ttf", "Sacramento", "sacramento"),
    "yellowtail": ("Yellowtail", "Regular", "Yellowtail-Regular.ttf", "Yellowtail", "yellowtail"),
    "mrdafoe": ("Mr Dafoe", "Regular", "MrDafoe-Regular.ttf", "Mr+Dafoe", "mrdafoe"),
    "pinyon":  ("Pinyon Script", "Regular", "PinyonScript-Regular.ttf", "Pinyon+Script", "pinyonscript"),
    "greatvibes": ("Great Vibes", "Regular", "GreatVibes-Regular.ttf", "Great+Vibes", "greatvibes"),
    "monsieur": ("Monsieur La Doulaise", "Regular", "MonsieurLaDoulaise-Regular.ttf", "Monsieur+La+Doulaise", "monsieurladoulaise"),
    "allura":  ("Allura", "Regular", "Allura-Regular.ttf", "Allura", "allura"),
    "damion":  ("Damion", "Regular", "Damion-Regular.ttf", "Damion", "damion"),
    "cond6":   ("Noto Serif Display", "wdth 62.5 · wght 600", "NotoSerifDisplay-Variable.ttf", "Noto+Serif+Display", "notoserifdisplay"),
    "cond3":   ("Noto Serif Display", "wdth 62.5 · wght 300", "NotoSerifDisplay-Variable.ttf", "Noto+Serif+Display", "notoserifdisplay"),
    "cond8":   ("Noto Serif Display", "wdth 62.5 · wght 800", "NotoSerifDisplay-Variable.ttf", "Noto+Serif+Display", "notoserifdisplay"),
}


def specs_from_log(log):
    last = {}
    order = []
    for fk, text, tr in log:
        if (fk, text) not in last:
            order.append((fk, text))
        last[(fk, text)] = tr  # keep the final value (K3 searches for its tracking)
    out = []
    for fk, text in order:
        fam, sett, file, gf, lic = FONT_INFO[fk]
        shown = {"L\u2019APRES": "L\u2019APRES + accent drawn over the E", "l\u2019apres": "l\u2019apres + accent drawn over the e"}.get(text, text)
        out.append(dict(family=fam, settings=sett, text=shown, tracking=f"{last[(fk, text)] * 1000:.0f}", file=file))
    return out


# ---------------------------------------------------------------- the marks
MARKS = []


def mark(id_, group, name, note, rnd=2):
    def deco(fn):
        MARKS.append(dict(id=id_, group=group, name=name, note=note, fn=fn, rnd=rnd))
        return fn
    return deco


# ---- The Spark (favourite, refined)
@mark("S1", "spark", "Spark Didone", "Bodoni Moda caps; a four-point spark takes the place of the grave accent.")
def _():
    w = spark_word("bodoni", 200)
    return w["word"], w["acc"]


@mark("S2", "spark", "Spark + Lodge line", "S1 over the HI-FI LISTENING LODGE line between hairlines, as on the deck’s door sign.")
def _():
    w = spark_word("bodoni", 200)
    base = lodge_line(w["width"], 200 * 0.62)
    return union(w["word"], base), w["acc"]


@mark("S3", "spark", "Italiana couture", "Thin poster capitals tracked wide, the most fashion of the set.")
def _():
    w = spark_word("italiana", 200, track=0.16, ratio=0.4)
    return union(w["word"], lodge_line(w["width"], 200 * 0.6)), w["acc"]


@mark("S4", "spark", "Cinzel lodge", "Carved Roman capitals, Alpine-hotel weight.")
def _():
    w = spark_word("cinzel", 200, track=0.08, ratio=0.42)
    return union(w["word"], lodge_line(w["width"], 200 * 0.6)), w["acc"]


@mark("S5", "spark", "Fat Didone", "Abril Fatface: the heaviest, made to glow as filled backlit letters.")
def _():
    w = spark_word("abril", 200, track=0.02, ratio=0.46)
    return w["word"], w["acc"]


@mark("S6", "spark", "Caslon maison", "Libre Caslon Display, softer and more Parisian, with the lodge line.")
def _():
    w = spark_word("caslon", 200, track=0.05)
    return union(w["word"], lodge_line(w["width"], 200 * 0.6)), w["acc"]


@mark("S7", "spark", "Lowercase spark", "Gloock lowercase l’après, warmer and sexier; spark over the e.")
def _():
    w = spark_word("gloock", 200, track=-0.005, lower=True, ratio=0.5, gap=0.22)
    return union(w["word"], lodge_line(w["width"], 200 * 0.5)), w["acc"]


@mark("S8", "spark", "Prata wide", "Prata Didone tracked wide with a smaller spark; quiet and expensive.")
def _():
    w = spark_word("prata", 200, track=0.14, ratio=0.36)
    return w["word"], w["acc"]


# ---- Flags (pennants)
def pennant(w, h, x=0, y=0):
    return [(x, y), (x + w, y + h / 2), (x, y + h)]


def fit_pennant(grp, W, H, x_start, margin, tip_x=None):
    """Scale grp so it sits left-aligned from x_start, vertically centred, and its right
    end still has `margin` clear inside the triangle (apex at tip_x, default W)."""
    tip = tip_x or W
    gx0, gy0, gx1, gy1 = bounds(grp)
    gw, gh = gx1 - gx0, gy1 - gy0
    k = ((H / 2) * (1 - x_start / tip) - margin) / (gw * H / (2 * tip) + gh / 2)
    g = moved(grp, -gx0, -gy0, 1, 1)
    g = moved(g, 0, 0, k, k)
    return moved(g, x_start, H / 2 - gh * k / 2)


def flag_body(W, H, hoist=48, gap=10):
    return minus(union(poly(pennant(W, H)), rect(0, 0, hoist, H)), rect(hoist, 0, gap, H))


@mark("F1", "flag", "Pennant", "A felt ski pennant; the spark wordmark is cut out of it, left-aligned to the hoist.")
def _():
    H, W = 340, 860
    w = spark_word("bodonik", 100, track=0.05)
    word = fit_pennant(union(w["word"], w["acc"]), W, H, 96, 28)
    return minus(flag_body(W, H), word), None


@mark("F2", "flag", "Pennant + Lodge", "A taller pennant with the wordmark and the lodge line cut out.")
def _():
    H, W = 400, 900
    w = spark_word("bodonik", 100, track=0.05)
    ll = line("mono", "HI-FI LISTENING LODGE", 100 * 0.2, 0, 0, 0.3, anchor="start")["path"]
    wb = bounds(w["word"])
    ll = moved(ll, wb[0] - bounds(ll)[0], wb[3] + 30 - bounds(ll)[1])
    grp = fit_pennant(union(w["word"], w["acc"], ll), W, H, 104, 34)
    return minus(flag_body(W, H, 50), grp), None


@mark("F3", "flag", "Burgee", "A swallowtail club flag, like an old yacht or ski-club burgee.")
def _():
    W, H = 800, 300
    flag = poly([(0, 0), (W, 0), (W - 120, H / 2), (W, H), (0, H)])
    w = spark_word("bodonik", 100, track=0.05)
    word = ink_center(union(w["word"], w["acc"]), cx=(W - 120) / 2, cy=H / 2)
    return minus(flag, word), None


@mark("F4", "flag", "Line pennant", "The pennant drawn as one line around the wordmark, a shape a sign-maker can bend in neon.")
def _():
    H, W = 300, 860
    tri = pennant(W, H)
    outline = minus(poly(tri), poly(inset_triangle(tri, 6)))
    hoist = rect(26, 6, 3, H - 12)
    w = spark_word("bodonik", 100, track=0.05)
    word = fit_pennant(union(w["word"], w["acc"]), W, H, 80, 34)
    return union(outline, hoist, word), None


# ---- Circles (more air between every ring)
@mark("C1", "circle", "Lodge seal", "Two rings, the lodge line on top, San Francisco below, the spark wordmark in the middle with clear space all round.")
def _():
    cx = cy = 0
    R = 300
    p = union(ring(cx, cy, R, 5), ring(cx, cy, R - 16, 1.6), ring(cx, cy, R - 96, 1.6))
    mono = 26
    p = union(p, arc_text("mono", "HI-FI LISTENING LODGE", mono, cx, cy, R - 66, track=0.34, where="top"))
    p = union(p, arc_text("mono", "SAN FRANCISCO", mono, cx, cy, R - 66 + mono * 0.72, track=0.34, where="bottom"))
    sm = mono * 0.7
    p = union(p, spark(-(R - 56), 0, sm), spark(R - 56, 0, sm))
    w = spark_word("bodonik", 64, track=0.05)
    word = ink_center(w["word"], cx=0, cy=0)
    dx = (bounds(word)[0] + bounds(word)[2]) / 2 - (bounds(w["word"])[0] + bounds(w["word"])[2]) / 2
    dy = (bounds(word)[1] + bounds(word)[3]) / 2 - (bounds(w["word"])[1] + bounds(w["word"])[3]) / 2
    acc = moved(w["acc"], dx, dy)
    g = ink_center(union(word, acc), cx=0, cy=0)
    off = (bounds(g)[1] - bounds(union(word, acc))[1])
    return union(p, moved(word, 0, off)), moved(acc, 0, off)


@mark("C2", "circle", "Record label", "A solid record label: wordmark, SESSIONS and the lodge line cut out, with room between every line and the spindle hole.")
def _():
    R = 300
    disc = circle(0, 0, R)
    mono = 24
    t = arc_text("mono", "SESSIONS", mono, 0, 0, R - 58, track=0.5, where="top")
    b = arc_text("mono", "HI-FI LISTENING LODGE", mono, 0, 0, R - 58 + mono * 0.72, track=0.34, where="bottom")
    w = spark_word("bodonik", 84, track=0.05)
    word = ink_center(union(w["word"], w["acc"]), cx=0, cy=-66)
    hole = circle(0, 62, 11)
    return minus(disc, union(t, b, word, hole)), None


@mark("C3", "circle", "Name ring", "L’APRÈS large on the top arc, the lodge line on the bottom arc, a big spark in the centre; one ring, lots of air.")
def _():
    R = 300
    p = ring(0, 0, R, 5)
    p = union(p, arc_text("bodonik", f"L{APOS}APRÈS", 74, 0, 0, R - 92, track=0.2, where="top"))
    p = union(p, arc_text("mono", "HI-FI LISTENING LODGE", 25, 0, 0, R - 70 + 25 * 0.72, track=0.34, where="bottom"))
    return p, spark(0, 0, 150)


@mark("C4", "circle", "Monogram seal", "L’A monogram under a spark, SESSIONS beneath, inside a double ring.")
def _():
    R = 300
    p = union(ring(0, 0, R, 5), ring(0, 0, R - 18, 1.6))
    t = line("bodoni", f"L{APOS}A", 230, 0, 0, 0.02)
    mono = ink_center(t["path"], cx=0, cy=14)
    s = spark(0, bounds(mono)[1] - 34 - 36, 72)
    ses = ink_center(line("mono", "SESSIONS", 24, 0, 0, 0.5)["path"], cx=0, cy=bounds(mono)[3] + 52)
    return union(p, mono, ses), s


# ---- Lockups
@mark("L1", "lockup", "Door sign", "Horizontal: spark wordmark, a hairline, then HI-FI / LISTENING LODGE on two lines. For the sign over the AMA door.")
def _():
    w = spark_word("bodoni", 200, track=0.04)
    x0, y0, x1, y1 = bounds(union(w["word"], w["acc"]))
    cap_top, base = bounds(w["word"])[1], bounds(w["word"])[3]
    rx = x1 + 60
    rule = rect(rx, cap_top - 6, 2.2, base - cap_top + 12)
    m = 40
    a = line("mono", "HI-FI", m, rx + 50, 0, 0.32, anchor="start")["path"]
    b = line("mono", "LISTENING LODGE", m, rx + 50, 0, 0.32, anchor="start")["path"]
    mid = (cap_top + base) / 2
    a = moved(a, 0, mid - 10 - bounds(a)[3])
    b = moved(b, 0, mid + 10 - bounds(b)[1])
    return union(w["word"], rule, a, b), w["acc"]


@mark("L2", "lockup", "Hotel plaque", "A double frame closed on all four sides, wordmark and lodge line inside.")
def _():
    w = spark_word("bodoni", 160, track=0.05)
    ll = lodge_line(w["width"], 160 * 0.62, rules=False, size=160 * 0.135)
    g = union(w["word"], w["acc"], ll)
    x0, y0, x1, y1 = bounds(g)
    pad_x, pad_y = 90, 70
    X0, Y0, X1, Y1 = x0 - pad_x, y0 - pad_y, x1 + pad_x, y1 + pad_y
    frame = minus(rect(X0, Y0, X1 - X0, Y1 - Y0), rect(X0 + 5, Y0 + 5, X1 - X0 - 10, Y1 - Y0 - 10))
    inner = minus(rect(X0 + 16, Y0 + 16, X1 - X0 - 32, Y1 - Y0 - 32), rect(X0 + 17.6, Y0 + 17.6, X1 - X0 - 35.2, Y1 - Y0 - 35.2))
    return union(frame, inner, w["word"], ll), w["acc"]


@mark("L3", "lockup", "Icon", "L’ and the spark cut out of a solid circle: profile picture, wristband, coaster.")
def _():
    R = 300
    t = line("bodoni", f"L{APOS}", 340, 0, 0, 0)
    m = ink_center(t["path"], cx=-44, cy=16)
    s = spark(bounds(m)[2] + 70, bounds(m)[1] + 6, 84)
    return minus(circle(0, 0, R), union(m, s)), None


@mark("L4", "lockup", "Sessions lockup", "The event-series lockup: spark wordmark, SESSIONS in tracked capitals, the lodge line last.")
def _():
    w = spark_word("bodoni", 200, track=0.04)
    wb = bounds(w["word"])
    ses = line("bodoni", "SESSIONS", 64, 0, 0, 0.62)["path"]
    ses = ink_center(ses, cx=(wb[0] + wb[2]) / 2, cy=wb[3] + 74)
    ll = lodge_line(w["width"], bounds(ses)[3] + 58, size=200 * 0.075, cx=(wb[0] + wb[2]) / 2)
    return union(w["word"], ses, ll), w["acc"]


# ================================================================ ROUND 3
# From the updated Pinterest board: sound marks (PulseClub), negative space (Camel, Jimmy J),
# condensed couture (A Main Levée, After Hours poster), arch and symbol systems (logo-concept sheet).

def stroked(pts, w, closed=False):
    p = new()
    pen = p.getPen()
    pen.moveTo(pts[0])
    for q in pts[1:]:
        pen.lineTo(q)
    pen.closePath() if closed else pen.endPath()
    p.stroke(w, pathops.LineCap.ROUND_CAP, pathops.LineJoin.ROUND_JOIN, 4)
    p.convertConicsToQuads()
    return pathops.simplify(p)


def zigzag_band(x0, x1, y, amp, n, th):
    """A zigzag strip (snowline / ridge) across x0..x1 centred on y, n teeth, thickness th."""
    xs = [x0 + (x1 - x0) * i / (2 * n) for i in range(2 * n + 1)]
    top = [(x, y + (-amp if i % 2 else amp)) for i, x in enumerate(xs)]
    bot = [(x, yy + th) for x, yy in reversed(top)]
    return poly(top + bot)


def eq_bars(n, bw, gap, heights, base=0):
    p = new()
    for i, h in enumerate(heights):
        x = i * (bw + gap)
        p = union(p, rect(x, base - h, bw, h))
    return p


def skyline(n, peaks, floor):
    hs = []
    for i in range(n):
        h = floor
        for c, H, w in peaks:
            h = max(h, H * (1 - abs(i - c) / w))
        hs.append(h)
    return hs


def word_block(fk, size, track, cx, top):
    """spark wordmark centred on cx with its spark top at `top`."""
    w = spark_word(fk, size, track=track)
    g = union(w["word"], w["acc"])
    x0, y0, x1, y1 = bounds(g)
    dx, dy = cx - (x0 + x1) / 2, top - y0
    return moved(w["word"], dx, dy), moved(w["acc"], dx, dy), w


# ---- Sound marks
@mark("P1", "sound", "EQ skyline", "Thirteen equaliser bars whose heights draw two Alpine peaks: hi-fi and lodge in one symbol, above the spark wordmark.", rnd=3)
def _():
    hs = skyline(13, [(4, 190, 4.2), (9, 130, 3.6)], 22)
    bars = eq_bars(13, 16, 9, hs)
    bx0, by0, bx1, by1 = bounds(bars)
    cx = (bx0 + bx1) / 2
    word, acc, w = word_block("bodoni", 150, 0.05, cx, by1 + 70)
    ll = lodge_line(w["width"], bounds(word)[3] + 62, size=150 * 0.11, cx=cx)
    return union(bars, word, ll), acc


@mark("P2", "sound", "Waveform peak", "A single sound line that rises into a mountain and settles again; one continuous stroke, ready for neon.", rnd=3)
def _():
    pts = [(0, 0)]
    x = 0
    for i, a in enumerate([6, 14, 8, 20, 12]):
        x += 22
        pts.append((x, -a if i % 2 == 0 else a))
    pts += [(x + 40, -40), (x + 120, -190), (x + 165, -120), (x + 195, -150), (x + 270, 0)]
    x = x + 270
    for i, a in enumerate([12, 20, 8, 14, 6]):
        x += 22
        pts.append((x, a if i % 2 == 0 else -a))
    pts.append((x + 22, 0))
    wave = stroked(pts, 6)
    bx0, by0, bx1, by1 = bounds(wave)
    cx = (bx0 + bx1) / 2
    word, acc, w = word_block("bodoni", 130, 0.05, cx, by1 + 60)
    return union(wave, word), acc


@mark("P3", "sound", "Pulse wordmark", "Condensed couture caps with a small EQ-peak icon sitting on the L, the way the PulseClub ref stacks its mark on the name.", rnd=3)
def _():
    w = spark_word("cond6", 220, track=0.03, ratio=0.4)
    word = w["word"]
    wb = bounds(word)
    hs = skyline(7, [(2, 74, 2.6), (5, 50, 2.0)], 12)
    bars = eq_bars(7, 9, 5, hs)
    b = bounds(bars)
    bars = moved(bars, wb[0] - b[0], wb[1] - 18 - b[3])
    return union(word, bars), w["acc"]


@mark("P4", "sound", "Record summit", "A solid record with a mountain ridge and the spark spindle cut out of it, over the wordmark.", rnd=3)
def _():
    R = 170
    disc = circle(0, 0, R)
    ridge = stroked([(-R - 10, 34), (-92, -10), (-58, 14), (-6, -70), (40, -18), (70, -40), (R + 10, 30)], 9)
    grooves = union(ring(0, 0, R - 22, 1.6), ring(0, 0, R - 40, 1.6))
    cut = union(minus(ridge, new()), spark(0, 74, 46), grooves)
    rec = minus(disc, cut)
    word, acc, w = word_block("bodoni", 120, 0.05, 0, R + 70)
    return union(rec, word), acc


# ---- Negative space
@mark("N1", "negative", "Snowline wordmark", "Heavy Didone caps with a ridge line cut through their tops, so the letters wear snow caps (the Camel idea).", rnd=3)
def _():
    w = spark_word("abril", 220, track=0.02, ratio=0.44)
    word = w["word"]
    x0, y0, x1, y1 = bounds(word)
    capt = y0
    band = zigzag_band(x0 - 10, x1 + 10, capt + (y1 - capt) * 0.24, 6, 8, 5)
    return minus(word, band), w["acc"]


@mark("N2", "negative", "Summit A", "The L’A monogram with a snowline cut across the apex of the A, so the A becomes the mountain.", rnd=3)
def _():
    t = line("bodonik", f"L{APOS}A", 300, 0, 0, 0.0)
    a = [g for ch, g in t["glyphs"] if ch == "A"][0]
    ax0, ay0, ax1, ay1 = bounds(a)
    band = zigzag_band(ax0 - 4, ax1 + 4, ay0 + (ay1 - ay0) * 0.34, 10, 4, 9)
    mono = union(*[g for ch, g in t["glyphs"] if ch != "A"], minus(a, band))
    mb = bounds(mono)
    cx = (mb[0] + mb[2]) / 2
    cap = line("mono", "HI-FI LISTENING LODGE", 25, cx, 0, 0.34)["path"]
    cap = ink_center(cap, cx=cx, cy=mb[3] + 56)
    return union(mono, cap), None


@mark("N3", "negative", "Lodge tile", "A solid square with the L, its apostrophe and the spark cut out; the spark fills the L’s open corner (the Jimmy J idea).", rnd=3)
def _():
    S_ = 400
    t = line("bodonik", f"L{APOS}", 330, 0, 0, 0)
    m = t["path"]
    mb = bounds(m)
    m = moved(m, -mb[0] + 78, -mb[1] + 62)
    mb = bounds(m)
    sp = spark(S_ * 0.74, S_ * 0.5, 78)
    return minus(rect(0, 0, S_, S_), union(m, sp)), None


@mark("N4", "negative", "Room key", "A lodge room-key fob: L’A and Nº cut out, a hole for the ring. For wristbands, coat check and VIP.", rnd=3)
def _():
    W, H = 260, 520
    fob = union(rect(0, W / 2, W, H - W), circle(W / 2, W / 2, W / 2), circle(W / 2, H - W / 2, W / 2))
    hole = circle(W / 2, 74, 24)
    t = line("bodonik", f"L{APOS}A", 140, 0, 0, 0)["path"]
    t = ink_center(t, cx=W / 2, cy=H * 0.52)
    num = line("mono", "Nº 01", 30, 0, 0, 0.2)["path"]
    num = ink_center(num, cx=W / 2, cy=bounds(t)[3] + 62)
    sp = spark(W / 2, bounds(t)[1] - 44, 40)
    return minus(fob, union(hole, t, num, sp)), None


# ---- Condensed couture
@mark("K1", "condensed", "Condensed couture", "Tall condensed high-contrast caps (Noto Serif Display, narrowest width) with the spark: the After Hours poster voice.", rnd=3)
def _():
    w = spark_word("cond6", 240, track=0.03, ratio=0.4)
    return w["word"], w["acc"]


@mark("K2", "condensed", "Condensed light + lodge", "The same cut in light weight, tracked open, with the lodge line between hairlines.", rnd=3)
def _():
    w = spark_word("cond3", 240, track=0.1, ratio=0.36)
    return union(w["word"], lodge_line(w["width"], 240 * 0.56)), w["acc"]


@mark("K3", "condensed", "Justified block", "L’APRÈS heavy over SESSIONS light, both set to exactly the same width; the lodge line closes the block.", rnd=3)
def _():
    w = spark_word("cond8", 220, track=0.02, ratio=0.42)
    wb = bounds(w["word"])
    target = wb[2] - wb[0]
    lo, hi = 0.0, 2.0
    for _ in range(30):
        mid = (lo + hi) / 2
        s = line("cond3", "SESSIONS", 120, 0, 0, mid)["path"]
        sb = bounds(s)
        if sb[2] - sb[0] < target:
            lo = mid
        else:
            hi = mid
    s = ink_center(s, cx=(wb[0] + wb[2]) / 2, cy=0)
    s = moved(s, 0, wb[3] + 30 - bounds(s)[1])
    ll = lodge_line(target, bounds(s)[3] + 46, size=220 * 0.07, cx=(wb[0] + wb[2]) / 2)
    return union(w["word"], s, ll), w["acc"]


@mark("K4", "condensed", "Arch door", "An arched lodge door: spark at the crown, L’ over APRÈS in condensed caps, the lodge line at the threshold.", rnd=3)
def _():
    W, H = 360, 600
    r = W / 2
    outer = union(rect(0, r, W, H - r), circle(r, r, r))
    inner = union(rect(8, r, W - 16, H - r - 8), circle(r, r, r - 8))
    frame = minus(outer, inner)
    sp = spark(r, r - 40, 64)
    l1 = ink_center(line("cond3", f"L{APOS}", 120, 0, 0, 0)["path"], cx=r, cy=r + 82)
    w = line("cond6", "APRÈS", 112, 0, 0, 0.04)["path"]
    w = ink_center(w, cx=r, cy=bounds(l1)[3] + 30 + 54)
    ll = line("mono", "HI-FI LISTENING LODGE", 15.5, 0, 0, 0.3)["path"]
    ll = ink_center(ll, cx=r, cy=H - 54)
    return union(frame, l1, w, ll), sp


# ================================================================ ROUND 1 (rebuilt as outlined vectors)
# Same fonts and settings as the Round 1 page (which used live web type). Units: 1cqi of the page = 4.

def ellipse(cx, cy, rx, ry):
    return moved(circle(0, 0, 1), cx, cy, rx, ry)


def ering(cx, cy, rx, ry, w):
    return minus(ellipse(cx, cy, rx + w / 2, ry + w / 2), ellipse(cx, cy, rx - w / 2, ry - w / 2))


def txt(fk, text, size, x, y, ls=0.0, anchor="middle"):
    """SVG-style text: ls = letter-spacing in px (converted to em)."""
    return line(fk, text, size, x, y, ls / size, anchor)["path"]


def peak_pts(x, y, w, h):
    return [(x, y + h), (x + w * .38, y), (x + w * .55, y + h * .38), (x + w * .66, y + h * .22), (x + w, y + h)]


def ring_text(fk, text, size, cx, cy, r, length):
    f, gl = shape(fk, text)
    w0 = sum(g[1] for g in gl) * size / f.upem
    return arc_text(fk, text, size, cx, cy, r, track=(length - w0) / ((len(gl) - 1) * size), where="top")


def accent_over_E(t, shape_fn):
    ep = [g for ch, g in t["glyphs"] if ch == "E"][0]
    x0, y0, x1, y1 = bounds(ep)
    return shape_fn((x0 + x1) / 2, y0)


def disc_mark(cx, cy, d):
    r = d / 2
    return minus(circle(cx, cy, r), minus(circle(cx, cy, r * 0.4), circle(cx, cy, r * 0.14)))


R1 = dict(rnd=1)

# ---- Route A · Couture Didone
@mark("A1", "A", "Maison caps", "Bodoni Moda caps, accent kept classic.", **R1)
def _():
    return txt("bodoni", f"L{APOS}APRÈS", 50, 0, 0, 1), None


@mark("A2", "A", "Spark accent", "The grave accent becomes a four-point spark.", **R1)
def _():
    w = spark_word("bodoni", 50, track=0.02, ratio=0.38, gap=0.12)
    return w["word"], w["acc"]


@mark("A3", "A", "Ski-slope accent", "The accent stretches into a hairline piste.", **R1)
def _():
    t = line("bodoni", f"L{APOS}APRES", 50, 0, 0, 0.02)
    def slope(cx, top):
        a = math.radians(-17)
        x0, y0 = cx - 0.06 * 50, top - 0.1 * 50
        return stroked([(x0, y0), (x0 + 57.5 * math.cos(a), y0 + 57.5 * math.sin(a))], 1.1)
    return t["path"], accent_over_E(t, slope)


@mark("A4", "A", "Italic L’", "A big italic L’ leans into tracked caps.", **R1)
def _():
    a = line("bodonit", f"L{APOS}", 96, 0, 0, 0, anchor="start")
    b = line("bodoni", "APRÈS", 42, a["width"] + 2, 0, 0.1, anchor="start")
    return union(a["path"], b["path"]), None


@mark("A5", "A", "Script over caps", "Wide Italiana caps with a script L’ and Sessions laid over them.", **R1)
def _():
    caps = line("italiana", "APRÈS", 48, 60, 0, 0.24, anchor="start")
    l = line("pinyon", f"L{APOS}", 88, 0, 10, 0, anchor="start")["path"]
    cb = bounds(caps["path"])
    s = line("pinyon", "Sessions", 36, cb[2] + 8, 40, 0, anchor="end")["path"]
    return union(caps["path"], l, s), None


@mark("A6", "A", "Italiana lodge", "Thin poster caps with a lodge caption.", **R1)
def _():
    w = txt("italiana", f"L{APOS}APRÈS", 48, 0, 0, 0.14 * 48)
    sub = txt("mono", "HI-FI LISTENING LODGE", 8.4, 0, bounds(w)[3] + 12.8 + 8.4, 0.32 * 8.4)
    return union(w, ink_center(sub, cx=(bounds(w)[0] + bounds(w)[2]) / 2)), None


@mark("A7", "A", "Cropped giant", "For key art: APRÈS too big for the frame.", **R1)
def _():
    W, H = 400, 250
    frame = rect(0, 0, W, H)
    l = txt("bodonit", f"L{APOS}", 36, 20, 20 + 36 * 0.9, anchor="start")
    s = txt("pinyon", "Sessions", 26, W - 20, 26 + 26 * 0.8, anchor="end")
    big = txt("bodoni8", "APRÈS", 116, 16, H + 28 - 116 * 0.12, -0.03 * 116, anchor="start")
    big = pathops.op(big, frame, pathops.PathOp.INTERSECTION)
    edge = minus(rect(-1, -1, W + 2, H + 2), rect(0, 0, W, H))
    return union(l, s, big, minus(rect(-0.6, -0.6, W + 1.2, H + 1.2), rect(0, 0, W, H))), None


@mark("A8", "A", "Lowercase Gloock", "Soft heavy lowercase, a spark over the e.", **R1)
def _():
    w = spark_word("gloock", 60, track=-0.01, lower=True, ratio=0.5, gap=0.05)
    return w["word"], w["acc"]


# ---- Route B · Neon Script
def script(fk, size):
    return txt(fk, f"L{APOS}Après", size, 0, 0)


@mark("B1", "B", "Sacramento", "The cleanest monoline, very neon.", **R1)
def _():
    return script("sacramento", 84), None


@mark("B2", "B", "Yellowtail", "A 1950s sign-painter script.", **R1)
def _():
    return script("yellowtail", 68), None


@mark("B3", "B", "Mr Dafoe", "A fast brush signature.", **R1)
def _():
    return script("mrdafoe", 76), None


@mark("B4", "B", "Damion + underline", "A bold rounded script with a swash underline.", **R1)
def _():
    w = script("damion", 64)
    b = bounds(w)
    cx, y = (b[0] + b[2]) / 2, b[3] + 6
    k = 208 / 292
    sw = new()
    pen = sw.getPen()
    pts = [(4, 14), (80, 2), (200, 2), (296, 10)]
    P = [(cx + (x - 150) * k, y + (yy - 8) * k) for x, yy in pts]
    pen.moveTo(P[0]); pen.curveTo(P[1], P[2], P[3]); pen.endPath()
    sw.stroke(3.2 * k * 1.4, pathops.LineCap.ROUND_CAP, pathops.LineJoin.ROUND_JOIN, 4)
    sw.convertConicsToQuads()
    return union(w, pathops.simplify(sw)), None


@mark("B5", "B", "Allura + Sessions", "A light script over tracked mono caps.", **R1)
def _():
    w = script("allura", 72)
    sub = txt("mono", "SESSIONS", 8.4, 0, bounds(w)[3] + 4 + 8.4, 0.32 * 8.4)
    return union(w, ink_center(sub, cx=(bounds(w)[0] + bounds(w)[2]) / 2)), None


@mark("B6", "B", "Pinyon couture", "Engraved contrast script.", **R1)
def _():
    return script("pinyon", 68), None


@mark("B7", "B", "Great Vibes", "Romantic and loopy.", **R1)
def _():
    return script("greatvibes", 72), None


@mark("B8", "B", "Monsieur", "A hairline flourish.", **R1)
def _():
    return script("monsieur", 80), None


# ---- Route C · Lodge Crest (coordinates from the Round 1 SVGs, 400 x 250)
@mark("C1", "C", "Oval badge", "A double-line oval club badge.", **R1)
def _():
    p = union(ering(200, 125, 176, 108, 2.2), ering(200, 125, 166, 98, 0.9))
    p = union(p, txt("mono4", "HI-FI · LISTENING · LODGE", 10, 200, 84, 3.4), txt("bodonit", f"L{APOS}Après", 62, 200, 145),
              txt("mono4", "SESSIONS · SAN FRANCISCO", 10, 200, 176, 3.4))
    return p, None


@mark("C2", "C", "Peak monogram", "The L’ sits under the peak.", **R1)
def _():
    return union(stroked(peak_pts(118, 22, 164, 104), 3), txt("bodonit", f"L{APOS}", 62, 200, 118),
                 txt("cinzel", f"L{APOS}APRÈS", 40, 200, 182, 9), txt("mono4", "HI-FI LISTENING LODGE", 10.5, 200, 214, 4)), None


@mark("C3", "C", "Ski-club shield", "A club shield with the L’A monogram.", **R1)
def _():
    sh = new()
    pen = sh.getPen()
    pen.moveTo((150, 20)); pen.lineTo((250, 20)); pen.lineTo((250, 120)); pen.curveTo((250, 168), (222, 196), (200, 230))
    pen.curveTo((178, 196), (150, 168), (150, 120)); pen.closePath()
    cut = union(txt("mono4", "CLUB", 10, 200, 52, 3.5), txt("bodonit", f"L{APOS}A", 56, 200, 132), txt("mono4", "MMXXVI", 10, 200, 168, 3.5))
    return minus(sh, cut), None


@mark("C4", "C", "Pennant", "A vintage ski-resort felt pennant.", **R1)
def _():
    flag = poly([(40, 40), (372, 125), (40, 210)])
    cut = union(rect(57.3, 44, 1.4, 162), txt("cinzel6", f"L{APOS}APRÈS", 38, 74, 136, 6, anchor="start"))
    return minus(flag, cut), None


@mark("C5", "C", "Round patch", "A sew-on patch with the peak and text running around it.", **R1)
def _():
    p = union(ring(200, 125, 112, 2.2), ring(200, 125, 74, 0.9))
    p = union(p, ring_text("mono4", f"L{APOS}APRÈS SESSIONS · HI-FI LISTENING LODGE · ", 12.5, 200, 125, 92, 574))
    p = union(p, stroked(peak_pts(150, 86, 100, 58), 2.4), txt("bodonit", f"L{APOS}Après", 22, 200, 174))
    return p, None


@mark("C6", "C", "Horizontal lockup", "A peak icon beside Cinzel caps.", **R1)
def _():
    return union(stroked(peak_pts(30, 90, 70, 48), 2.6), rect(117.5, 82, 1, 86), txt("cinzel", f"L{APOS}APRÈS", 44, 136, 128, 6, anchor="start"),
                 txt("mono4", "HI-FI LISTENING LODGE", 10.5, 138, 158, 4, anchor="start")), None


@mark("C7", "C", "Admit one", "A lift-pass and ticket stub.", **R1)
def _():
    outer = minus(rect(29, 49, 342, 152), union(circle(370, 125, 19), circle(30, 125, 19)))
    inner = minus(rect(31, 51, 338, 148), union(circle(370, 125, 21), circle(30, 125, 21)))
    p = minus(outer, inner)
    for y in range(56, 194, 9):
        p = union(p, rect(289.4, y, 1.2, 4))
    p = union(p, txt("mono4", "ADMIT ONE", 10.5, 160, 86, 4), txt("bodonit", f"L{APOS}Après", 50, 160, 142),
              txt("mono4", "SESSIONS", 10.5, 160, 176, 4), txt("cinzel6", "N°", 22, 330, 131))
    return p, None


@mark("C8", "C", "Engraved caps", "Cinzel between hairline rules.", **R1)
def _():
    w = txt("cinzel", f"L{APOS}APRÈS", 38, 0, 0, 0.16 * 38)
    b = bounds(w)
    mid = (b[1] + b[3]) / 2
    rules = union(rect(b[0] - 12 - 36, mid, 36, 1), rect(b[2] + 12, mid, 36, 1))
    sub = txt("mono", "EST. MMXXVI · SAN FRANCISCO", 8.4, (b[0] + b[2]) / 2, b[3] + 12.8 + 8.4, 0.32 * 8.4)
    return union(w, rules, sub), None


# ---- Route D · Centre Label
@mark("D1", "D", "Solid label", "A full record label.", **R1)
def _():
    cut = union(circle(200, 125, 6), arc_text("mono4", "SESSIONS · SIDE A", 11, 200, 125, 94, 4 / 11, "top"),
                arc_text("mono4", "HI-FI LISTENING LODGE · 33⅓", 11, 200, 125, 104, 4 / 11, "bottom"), txt("bodonit", f"L{APOS}Après", 44, 200, 100))
    return minus(circle(200, 125, 114), cut), None


@mark("D2", "D", "In the grooves", "The label inside fine record grooves.", **R1)
def _():
    p = new()
    for i in range(12):
        p = union(p, ring(200, 125, 60 + i * 5, 1.1 if i % 4 == 3 else 0.5))
    lab = minus(circle(200, 125, 54), union(circle(200, 125, 3.5), txt("bodonit", f"L{APOS}Après", 19, 200, 111), txt("mono4", "SESSIONS", 6.5, 200, 149, 2.4)))
    return union(p, lab), None


@mark("D3", "D", "Name ring", "L’APRÈS round the record, a spark at the spindle.", **R1)
def _():
    p = union(ring(200, 125, 112, 2), ring(200, 125, 64, 0.8), ring_text("bodoni", f"L{APOS}APRÈS · L{APOS}APRÈS · L{APOS}APRÈS · ", 27, 200, 125, 88, 550))
    return p, spark(200, 125, 36)


@mark("D4", "D", "Half out of the sleeve", "A sleeve with the record sliding out.", **R1)
def _():
    disc = minus(circle(250, 125, 100), union(rect(60, 20, 210, 210), circle(250, 125, 34)))
    sleeve = minus(rect(59, 19, 212, 212), rect(61, 21, 208, 208))
    return union(disc, circle(250, 125, 3), sleeve, txt("mono4", "SESSIONS · Nº 01", 9.5, 78, 62, 3, anchor="start"),
                 txt("bodonit", f"L{APOS}Après", 44, 78, 212, anchor="start")), None


@mark("D5", "D", "Tonearm apostrophe", "Rejected in review; kept for the record.", **R1)
def _():
    s = 60
    l = line("bodoni", "L", s, 0, 0, 0, anchor="start")
    x = l["width"] + 0.0
    k = (0.62 * s) / 62
    ox, oy = x - 0.02 * s, -0.1 * s - 62 * k
    T = lambda px, py: (ox + px * k, oy + py * k)
    arm = union(minus(circle(*T(27, 7), 6 * k), circle(*T(27, 7), 3.6 * k)), circle(*T(27, 7), 2 * k), stroked([T(27, 7), T(24, 38), T(11, 50)], 2.4 * k))
    head = poly([T(2, 46), T(15, 46), T(15, 55), T(2, 55)])
    a = line("bodoni", "Après", s, x + 0.33 * s, 0, 0.01, anchor="start")
    return union(l["path"], arm, head, a["path"]), None


@mark("D6", "D", "Record accent", "The È accent is a tiny record.", **R1)
def _():
    t = line("bodoni", f"L{APOS}APRES", 50, 0, 0, 0.02)
    return t["path"], accent_over_E(t, lambda cx, top: disc_mark(cx, top - 0.05 * 50 - 7.5, 15))


@mark("D7", "D", "Monogram label", "An outline label with a large L’A monogram.", **R1)
def _():
    return union(ring(200, 125, 112, 2.2), ring(200, 125, 104, 0.8), txt("bodonit", f"L{APOS}A", 96, 200, 140), circle(200, 178, 4.5),
                 txt("mono4", "SESSIONS", 9.5, 200, 208, 3.6)), None


@mark("D8", "D", "Spark spindle", "A clean label with a spark at the spindle.", **R1)
def _():
    p = union(ring(200, 125, 112, 2), arc_text("bodoni", f"L{APOS}APRÈS", 24, 200, 125, 90, 7 / 24, "top"),
              arc_text("mono4", "HI-FI LISTENING LODGE", 10, 200, 125, 100, 0.4, "bottom"))
    return p, spark(200, 125, 60)


# ---------------------------------------------------------------- export
def d_of(p):
    pen = SVGPathPen(None, ntos=lambda v: ("%.2f" % v).rstrip("0").rstrip("."))
    p.draw(pen)
    return pen.getCommands()


def build(rnd):
    out = ROOT / "logos" / f"r{rnd}"
    out.mkdir(parents=True, exist_ok=True)
    data = []
    for m in [m for m in MARKS if m["rnd"] == rnd]:
        LOG.clear()
        main, acc = m["fn"]()
        spec = specs_from_log(LOG)
        main = pathops.simplify(main) if main is not None else None
        acc = pathops.simplify(acc) if acc is not None else None
        allp = union(main, acc)
        x0, y0, x1, y1 = bounds(allp)
        w, h = x1 - x0, y1 - y0
        pad = max(w, h) * 0.04
        vb = f"{x0 - pad:.2f} {y0 - pad:.2f} {w + 2 * pad:.2f} {h + 2 * pad:.2f}"
        dm, da = d_of(main), (d_of(acc) if acc is not None else "")
        file_svg = (
            f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{vb}" width="{w + 2 * pad:.0f}" height="{h + 2 * pad:.0f}">'
            f'<title>L’Après {m["id"]} {m["name"]}</title>'
            f'<path d="{dm}" fill="#121010"/>' + (f'<path id="accent" d="{da}" fill="#121010"/>' if da else "") + "</svg>"
        )
        slug = re.sub(r"[^a-z0-9]+", "-", m["name"].lower().replace("’", "").replace(" + ", " ")).strip("-")
        fn = f"lapres-{m['id']}-{slug}.svg"
        (out / fn).write_text(file_svg)
        data.append(dict(id=m["id"], group=m["group"], name=m["name"], note=m["note"], vb=vb, d=dm, a=da, file=f"logos/r{rnd}/{fn}", ratio=round(w / h, 3), spec=spec))
        print(f"{m['id']:3} {w:7.1f} x {h:6.1f}  {fn}")
    (ROOT / f"r{rnd}-data.js").write_text(f"window.R{rnd}=" + json.dumps(data, ensure_ascii=False) + ";\n")


if __name__ == "__main__":
    import sys
    for r in (sys.argv[1:] or ["1", "2", "3"]):
        build(int(r))
