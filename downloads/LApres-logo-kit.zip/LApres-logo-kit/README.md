# L’Après — logo kit

RemotoLabs® for RASA · Nights of Wonder · L’Après, Hi-Fi Listening Lodge
Presentation: https://n333k0.github.io/l-apres/

## Español

**Qué hay en este zip**

- `logos/round-1/`, `logos/round-2/` y `logos/round-3/`: los 64 logos en SVG, vectores limpios con el texto ya convertido a curvas. Se abren en Illustrator, Figma o Affinity. El spark de cada wordmark está en su propio trazado (`id="accent"`), así se puede pintar de dorado aparte.
- En Figma: arrastrá el SVG al lienzo para usarlo como vector, o instalá las fuentes y volvé a escribir el texto con los valores de `specs.csv` para poder editarlo.
- `logos/spark.svg`: el spark de cuatro puntas solo. No es una letra: es una forma propia que reemplaza el acento grave de la È.
- `fonts/`: las 17 tipografías originales de Google Fonts (las de los tres rounds, incluidas las script del Round 1), sin modificar, con su licencia en `fonts/licenses/` (SIL Open Font License; Yellowtail es Apache 2.0). Son gratis, también para uso comercial y para logos.
- `specs.csv`: para cada logo, qué tipografía usa, con qué ajuste (peso, ancho, tamaño óptico), qué texto y con qué interletra.
- `source/`: el script que genera los logos (`build.py`), por si se quieren regenerar o cambiar en código.

**Cómo rehacer un logo en Illustrator o Figma**

1. Instalá las fuentes de `fonts/` (doble clic en cada .ttf).
2. Buscá el logo en `specs.csv`.
3. Las fuentes “Variable” tienen ejes. En Illustrator: panel Carácter → ícono de fuente variable. En Figma: Tipo → “Variable font axes”. Poné los valores exactos:
   - Bodoni Moda: `opsz 28 · wght 500` para los wordmarks grandes; `opsz 11 · wght 600` para las versiones chicas y caladas (banderas, sellos, llavero). Con opsz alto los filetes finos desaparecen.
   - Noto Serif Display: `wdth 62.5` (el más angosto) con `wght` 300, 600 u 800.
   - Cinzel: `wght 500`.
4. La interletra de `specs.csv` está en milésimas de em, la misma unidad que el Tracking de Illustrator y Figma (por ejemplo 40 = 40).
5. Escribí L’APRES sin acento y poné `spark.svg` sobre la E, centrado en la E. Su alto es cerca del 44% de la altura de mayúsculas, con un espacio de cerca del 17% de esa altura sobre la E.
6. Usá siempre el apóstrofo tipográfico ’ (no la comilla recta ').
7. Antes de exportar, convertí el texto a curvas.

## English

`logos/` holds 64 outlined SVGs (Rounds 1–3), with the spark as a separate path (`id="accent"`). `fonts/` holds the original Google Fonts files (SIL OFL, licences in `fonts/licenses/`). `specs.csv` lists each logo’s family, axis settings, text and tracking (1/1000 em, the same unit as Illustrator and Figma tracking). `logos/spark.svg` is the spark that replaces the grave accent. `source/build.py` regenerates everything (Python 3, `pip install -r source/requirements.txt`, then put the original font files in `fonts/`).

Fonts: Bodoni Moda (roman and italic), Noto Serif Display, Italiana, Cinzel, Abril Fatface, Libre Caslon Display, Gloock, Prata, DM Mono, and the Round 1 scripts Sacramento, Yellowtail, Mr Dafoe, Pinyon Script, Great Vibes, Monsieur La Doulaise, Allura and Damion. All are SIL Open Font License 1.1 except Yellowtail (Apache 2.0). Abril Fatface and Italiana have Reserved Font Names, so only the original files are included here.
